﻿namespace Calculadora_Basica
{
    partial class CalculadoraBasicaGUI
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Operaciones = new System.Windows.Forms.TextBox();
            this.borrarcalculos1 = new System.Windows.Forms.Button();
            this.uno = new System.Windows.Forms.Button();
            this.dos = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.tres = new System.Windows.Forms.Button();
            this.cuatro = new System.Windows.Forms.Button();
            this.cinco = new System.Windows.Forms.Button();
            this.seis = new System.Windows.Forms.Button();
            this.siete = new System.Windows.Forms.Button();
            this.ocho = new System.Windows.Forms.Button();
            this.nueve = new System.Windows.Forms.Button();
            this.suma = new System.Windows.Forms.Button();
            this.resta = new System.Windows.Forms.Button();
            this.multiplicacion = new System.Windows.Forms.Button();
            this.division = new System.Windows.Forms.Button();
            this.cero = new System.Windows.Forms.Button();
            this.punto = new System.Windows.Forms.Button();
            this.coma = new System.Windows.Forms.Button();
            this.igual = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Operaciones
            // 
            this.Operaciones.Location = new System.Drawing.Point(12, 12);
            this.Operaciones.Name = "Operaciones";
            this.Operaciones.ReadOnly = true;
            this.Operaciones.Size = new System.Drawing.Size(262, 20);
            this.Operaciones.TabIndex = 0;
            // 
            // borrarcalculos1
            // 
            this.borrarcalculos1.Location = new System.Drawing.Point(104, 38);
            this.borrarcalculos1.Name = "borrarcalculos1";
            this.borrarcalculos1.Size = new System.Drawing.Size(75, 23);
            this.borrarcalculos1.TabIndex = 1;
            this.borrarcalculos1.Text = "CE";
            this.borrarcalculos1.UseVisualStyleBackColor = true;
            this.borrarcalculos1.Click += new System.EventHandler(this.borrarcalculos1_Click);
            // 
            // uno
            // 
            this.uno.Location = new System.Drawing.Point(12, 106);
            this.uno.Name = "uno";
            this.uno.Size = new System.Drawing.Size(75, 42);
            this.uno.TabIndex = 2;
            this.uno.Text = "1";
            this.uno.UseVisualStyleBackColor = true;
            this.uno.Click += new System.EventHandler(this.uno_Click);
            // 
            // dos
            // 
            this.dos.Location = new System.Drawing.Point(12, 154);
            this.dos.Name = "dos";
            this.dos.Size = new System.Drawing.Size(75, 42);
            this.dos.TabIndex = 3;
            this.dos.Text = "2";
            this.dos.UseVisualStyleBackColor = true;
            this.dos.Click += new System.EventHandler(this.dos_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1158, 357);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 42);
            this.button3.TabIndex = 4;
            this.button3.Text = "CE";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(647, 272);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 42);
            this.button4.TabIndex = 5;
            this.button4.Text = "CE";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // tres
            // 
            this.tres.Location = new System.Drawing.Point(12, 202);
            this.tres.Name = "tres";
            this.tres.Size = new System.Drawing.Size(75, 42);
            this.tres.TabIndex = 6;
            this.tres.Text = "3";
            this.tres.UseVisualStyleBackColor = true;
            this.tres.Click += new System.EventHandler(this.tres_Click);
            // 
            // cuatro
            // 
            this.cuatro.Location = new System.Drawing.Point(104, 106);
            this.cuatro.Name = "cuatro";
            this.cuatro.Size = new System.Drawing.Size(75, 42);
            this.cuatro.TabIndex = 7;
            this.cuatro.Text = "4";
            this.cuatro.UseVisualStyleBackColor = true;
            this.cuatro.Click += new System.EventHandler(this.cuatro_Click);
            // 
            // cinco
            // 
            this.cinco.Location = new System.Drawing.Point(104, 154);
            this.cinco.Name = "cinco";
            this.cinco.Size = new System.Drawing.Size(75, 42);
            this.cinco.TabIndex = 8;
            this.cinco.Text = "5";
            this.cinco.UseVisualStyleBackColor = true;
            this.cinco.Click += new System.EventHandler(this.cinco_Click);
            // 
            // seis
            // 
            this.seis.Location = new System.Drawing.Point(104, 202);
            this.seis.Name = "seis";
            this.seis.Size = new System.Drawing.Size(75, 42);
            this.seis.TabIndex = 9;
            this.seis.Text = "6";
            this.seis.UseVisualStyleBackColor = true;
            this.seis.Click += new System.EventHandler(this.seis_Click);
            // 
            // siete
            // 
            this.siete.Location = new System.Drawing.Point(199, 106);
            this.siete.Name = "siete";
            this.siete.Size = new System.Drawing.Size(75, 42);
            this.siete.TabIndex = 10;
            this.siete.Text = "7";
            this.siete.UseVisualStyleBackColor = true;
            this.siete.Click += new System.EventHandler(this.siete_Click);
            // 
            // ocho
            // 
            this.ocho.Location = new System.Drawing.Point(199, 154);
            this.ocho.Name = "ocho";
            this.ocho.Size = new System.Drawing.Size(75, 42);
            this.ocho.TabIndex = 11;
            this.ocho.Text = "8";
            this.ocho.UseVisualStyleBackColor = true;
            this.ocho.Click += new System.EventHandler(this.ocho_Click);
            // 
            // nueve
            // 
            this.nueve.Location = new System.Drawing.Point(199, 202);
            this.nueve.Name = "nueve";
            this.nueve.Size = new System.Drawing.Size(75, 42);
            this.nueve.TabIndex = 12;
            this.nueve.Text = "9";
            this.nueve.UseVisualStyleBackColor = true;
            this.nueve.Click += new System.EventHandler(this.nueve_Click);
            // 
            // suma
            // 
            this.suma.Location = new System.Drawing.Point(12, 272);
            this.suma.Name = "suma";
            this.suma.Size = new System.Drawing.Size(75, 28);
            this.suma.TabIndex = 13;
            this.suma.Text = "+";
            this.suma.UseVisualStyleBackColor = true;
            this.suma.Click += new System.EventHandler(this.suma_Click);
            // 
            // resta
            // 
            this.resta.Location = new System.Drawing.Point(104, 272);
            this.resta.Name = "resta";
            this.resta.Size = new System.Drawing.Size(75, 28);
            this.resta.TabIndex = 14;
            this.resta.Text = "-";
            this.resta.UseVisualStyleBackColor = true;
            this.resta.Click += new System.EventHandler(this.resta_Click);
            // 
            // multiplicacion
            // 
            this.multiplicacion.Location = new System.Drawing.Point(199, 273);
            this.multiplicacion.Name = "multiplicacion";
            this.multiplicacion.Size = new System.Drawing.Size(75, 28);
            this.multiplicacion.TabIndex = 15;
            this.multiplicacion.Text = "X";
            this.multiplicacion.UseVisualStyleBackColor = true;
            this.multiplicacion.Click += new System.EventHandler(this.multiplicacion_Click);
            // 
            // division
            // 
            this.division.Location = new System.Drawing.Point(104, 325);
            this.division.Name = "division";
            this.division.Size = new System.Drawing.Size(75, 29);
            this.division.TabIndex = 16;
            this.division.Text = "÷";
            this.division.UseVisualStyleBackColor = true;
            this.division.Click += new System.EventHandler(this.division_Click);
            // 
            // cero
            // 
            this.cero.Location = new System.Drawing.Point(199, 70);
            this.cero.Name = "cero";
            this.cero.Size = new System.Drawing.Size(75, 21);
            this.cero.TabIndex = 19;
            this.cero.Text = "0";
            this.cero.UseVisualStyleBackColor = true;
            this.cero.Click += new System.EventHandler(this.cero_Click);
            // 
            // punto
            // 
            this.punto.Location = new System.Drawing.Point(104, 70);
            this.punto.Name = "punto";
            this.punto.Size = new System.Drawing.Size(75, 21);
            this.punto.TabIndex = 20;
            this.punto.Text = ".";
            this.punto.UseVisualStyleBackColor = true;
            this.punto.Click += new System.EventHandler(this.punto_Click);
            // 
            // coma
            // 
            this.coma.Location = new System.Drawing.Point(12, 70);
            this.coma.Name = "coma";
            this.coma.Size = new System.Drawing.Size(75, 21);
            this.coma.TabIndex = 21;
            this.coma.Text = ",";
            this.coma.UseVisualStyleBackColor = true;
            this.coma.Click += new System.EventHandler(this.coma_Click);
            // 
            // igual
            // 
            this.igual.Location = new System.Drawing.Point(199, 38);
            this.igual.Name = "igual";
            this.igual.Size = new System.Drawing.Size(75, 23);
            this.igual.TabIndex = 22;
            this.igual.Text = "=";
            this.igual.UseVisualStyleBackColor = true;
            this.igual.Click += new System.EventHandler(this.igual_Click);
            // 
            // CalculadoraBasicaGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 377);
            this.Controls.Add(this.igual);
            this.Controls.Add(this.coma);
            this.Controls.Add(this.punto);
            this.Controls.Add(this.cero);
            this.Controls.Add(this.division);
            this.Controls.Add(this.multiplicacion);
            this.Controls.Add(this.resta);
            this.Controls.Add(this.suma);
            this.Controls.Add(this.nueve);
            this.Controls.Add(this.ocho);
            this.Controls.Add(this.siete);
            this.Controls.Add(this.seis);
            this.Controls.Add(this.cinco);
            this.Controls.Add(this.cuatro);
            this.Controls.Add(this.tres);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.dos);
            this.Controls.Add(this.uno);
            this.Controls.Add(this.borrarcalculos1);
            this.Controls.Add(this.Operaciones);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CalculadoraBasicaGUI";
            this.Text = "Calculadora Basica";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Operaciones;
        private System.Windows.Forms.Button borrarcalculos1;
        private System.Windows.Forms.Button uno;
        private System.Windows.Forms.Button dos;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button tres;
        private System.Windows.Forms.Button cuatro;
        private System.Windows.Forms.Button cinco;
        private System.Windows.Forms.Button seis;
        private System.Windows.Forms.Button siete;
        private System.Windows.Forms.Button ocho;
        private System.Windows.Forms.Button nueve;
        private System.Windows.Forms.Button suma;
        private System.Windows.Forms.Button resta;
        private System.Windows.Forms.Button multiplicacion;
        private System.Windows.Forms.Button division;
        private System.Windows.Forms.Button cero;
        private System.Windows.Forms.Button punto;
        private System.Windows.Forms.Button coma;
        private System.Windows.Forms.Button igual;
    }
}

