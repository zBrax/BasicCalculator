﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_Basica
{
    public partial class CalculadoraBasicaGUI : Form
    {
 
        double primero;
        double segundo;
        double resultado;
        string operacion;

        public CalculadoraBasicaGUI()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void uno_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + "1";
        }

        private void dos_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + "2";
        }

        private void tres_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + "3";
        }

        private void cuatro_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + "4";
        }

        private void cinco_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + "5";
        }

        private void seis_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + "6";
        }

        private void siete_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + "7";
        }

        private void ocho_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + "8";
        }

        private void nueve_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + "9";
        }

        private void punto_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + ".";
        }

        private void coma_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + ",";
        }

        private void cero_Click(object sender, EventArgs e)
        {
            Operaciones.Text = Operaciones.Text + "0";
        }

        private void suma_Click(object sender, EventArgs e)
        {
            operacion = "+";
            primero = double.Parse(Operaciones.Text);
            Operaciones.Clear();
        }

        private void resta_Click(object sender, EventArgs e)
        {
            operacion = "-";
            primero = double.Parse(Operaciones.Text);
            Operaciones.Clear();
        }

        private void multiplicacion_Click(object sender, EventArgs e)
        {
            operacion = "*";
            primero = double.Parse(Operaciones.Text);
            Operaciones.Clear();
        }

        private void division_Click(object sender, EventArgs e)
        {
            operacion = "/";
            primero = double.Parse(Operaciones.Text);
            Operaciones.Clear();
        }

        private void borrarcalculos1_Click(object sender, EventArgs e)
        {
            Operaciones.Clear();

        }

        private void igual_Click(object sender, EventArgs e)
        {
            segundo = double.Parse(Operaciones.Text);

            
            switch (operacion){
                case "+":
                    resultado = primero + segundo;
                    Operaciones.Text = resultado.ToString();
                    break;
                case "-":
                    resultado = primero - segundo;
                    Operaciones.Text = resultado.ToString();
                    break;
                case "*":
                    resultado = primero * segundo;
                    Operaciones.Text = resultado.ToString();
                    break;
                case "/":
                    resultado = primero / segundo;
                    Operaciones.Text = resultado.ToString();
                    break;



            }

        }
    }
}
